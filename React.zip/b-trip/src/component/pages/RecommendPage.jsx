import React from 'react';
import PropTypes from 'prop-types';

const RecommendPage = () => {
  return (
    <div>
      <h2>추천페이지</h2>
      <a href='/result'>결과</a>
    </div>
  );
};


export default RecommendPage;