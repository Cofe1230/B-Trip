import React from 'react';


const RecommendResultPage = () => {
  return (
    <div>
      <h2>결과</h2>
    </div>
  );
};


export default RecommendResultPage;