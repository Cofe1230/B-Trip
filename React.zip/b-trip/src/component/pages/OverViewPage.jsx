import React from 'react';
import PropTypes from 'prop-types';

const OverViewPage = () => {
  return (
    <div>
      <h2>개요, 분석 설명?</h2>
    </div>
  );
};


export default OverViewPage;