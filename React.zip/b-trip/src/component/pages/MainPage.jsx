import React from 'react';
import PropTypes from 'prop-types';

const MainPage = () => {
  return (
    <div>
      <h2>Home</h2>
    </div>
  );
};

export default MainPage;