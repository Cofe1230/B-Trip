package com.dataproject.btrip;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BTripApplication {

	public static void main(String[] args) {
		SpringApplication.run(BTripApplication.class, args);
	}

}
